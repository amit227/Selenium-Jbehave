package utils;

public class DataSetter {


	static String pswd="";
	static String usrnme="";

	public static String getPassword()
	{
	    return pswd;
	}

	public static void setPassword(String passwd)
	{
	    pswd=passwd;
	}

	public static String getUsername()
	{
	    return usrnme;
	}


	public static void setUsername(String username)
	{
	    usrnme = username;
	}
	 
}
