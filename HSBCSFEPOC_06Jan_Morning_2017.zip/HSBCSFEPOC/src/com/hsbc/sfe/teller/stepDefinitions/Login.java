package com.hsbc.sfe.teller.stepDefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hsbc.sfe.teller.Helpers.InitDriver;
import com.hsbc.sfe.teller.elements_Factory.CustomerDetailsPopup_elements;
import com.hsbc.sfe.teller.elements_Factory.CustomerSearchPopUp_Elements;
import com.hsbc.sfe.teller.elements_Factory.LandingPage_Elements;
import com.hsbc.sfe.teller.elements_Factory.LoginPage_Elements;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Login {
	static WebDriver driver = InitDriver.driver();
	public static LandingPage_Elements Landingwebe = LandingPage_Elements.getinstance(driver);
	public static LoginPage_Elements Loginwebe = LoginPage_Elements.getinstance(driver);
	public static CustomerDetailsPopup_elements Custdetailswebe = CustomerDetailsPopup_elements.getinstance(driver);
	public static CustomerSearchPopUp_Elements CustSearchwebe = CustomerSearchPopUp_Elements.getinstance(driver);
	

	@And("^User enters UserName and Password$")
	public void user_enters_UserName_and_Password() throws Throwable {
		Loginwebe.txt_UserID.sendKeys("QATST204");
		Loginwebe.txt_Password.sendKeys("Password1");
		Loginwebe.btn_LogIn.click();		
	}

	@When("^User clicks on the Login button on the next page$")
	public void user_clicks_on_the_Login_button_on_the_next_page() throws Throwable {
		new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(Loginwebe.btn_Login2));
		Loginwebe.btn_Login2.click();
	}

	@When("^User clicks on the continue button on the page$")
	public void user_clicks_on_the_continue_button_on_the_page() throws Throwable {
		new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(Loginwebe.btn_continueToHomePage));
		Loginwebe.btn_continueToHomePage.click();
	}
	@Then("^Message displayed Login Successfully$")
	public void message_displayed_Login_Successfully() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}
}
