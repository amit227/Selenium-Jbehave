package com.hsbc.sfe.teller.stepDefinitions;

import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.server.handler.NewSession;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.GherkinKeyword;
import com.aventstack.extentreports.gherkin.model.IGherkinFormatterModel;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.ExtentXReporter;
import com.cucumber.listener.ExtentCucumberFormatter;
import com.hsbc.sfe.teller.Helpers.InitDriver;
import com.hsbc.sfe.teller.Runner.RunTest;
import com.hsbc.sfe.teller.elements_Factory.CustomerDetailsPopup_elements;
import com.hsbc.sfe.teller.elements_Factory.CustomerSearchPopUp_Elements;
import com.hsbc.sfe.teller.elements_Factory.LandingPage_Elements;
import com.hsbc.sfe.teller.elements_Factory.LoginPage_Elements;

import cucumber.api.PendingException;
import cucumber.api.Scenario;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.runtime.FeatureBuilder;
import cucumber.runtime.RuntimeOptions;
import cucumber.runtime.io.ResourceLoader;
import cucumber.runtime.model.CucumberFeature;
import gherkin.formatter.model.Feature;

public class CustomerSearch {
	
	static WebDriver driver = InitDriver.driver();
	
	public static LandingPage_Elements Landingwebe = LandingPage_Elements.getinstance(driver);
	public static LoginPage_Elements Loginwebe = LoginPage_Elements.getinstance(driver);
	public static CustomerDetailsPopup_elements Custdetailswebe = CustomerDetailsPopup_elements.getinstance(driver);
	public static CustomerSearchPopUp_Elements CustSearchwebe = CustomerSearchPopUp_Elements.getinstance(driver);
	
	
	
	
	
	
	@Given("^User is on home page$")
	public void User_On_Home_Page() throws InterruptedException, ClassNotFoundException {
		
		Thread.sleep(2000);
		
		
		if (driver.findElement(By.xpath("//span[contains(text(),'Overview')]")).isEnabled()) 
		{
			System.out.println("It is displayed");
		}
		else
		{
			driver.get("http://cd499.p2g.netd2.hk.hsbc/1/2/");
			driver.manage().window().maximize();
			Loginwebe.txt_Password.sendKeys("Password1");
			Loginwebe.btn_LogIn.click();	
			new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(Loginwebe.btn_Login2));
			Loginwebe.btn_Login2.click();
			new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(Loginwebe.btn_continueToHomePage));
			Loginwebe.btn_continueToHomePage.click();
			Thread.sleep(2000);			
		}
	}

	@When("^User Searches customer$")
	public void user_Searches_Customer() throws Throwable {
		Actions action = new Actions(driver);
		action.moveToElement(Landingwebe.lnk_Customer).build().perform();
		Thread.sleep(2000);
		//String ParentWindow=driver.getWindowHandle();
		CustSearchwebe.link_customerTitle.click();
		CustSearchwebe.txt_BranchCode.sendKeys("2");;
		CustSearchwebe.txt_Serial_Number.sendKeys("610"+Keys.TAB);
		CustSearchwebe.btn_Search.click();
		/*driver.findElement(By.xpath("//span[@title='Customer Overview']")).click();
		driver.findElement(By.xpath("(//div[@class='HUBAccountdiv'])[1]//div[@class='dijitReset dijitInputField dijitInputContainer activeInput']//input[@title='Branch Code']")).sendKeys("2");
		driver.findElement(By.xpath("(//div[@class='HUBAccountdiv'])[1]//div[@class='dijitReset dijitInputField dijitInputContainer activeInput']//input[@title='Serial Number']")).sendKeys("610"+Keys.TAB);
		driver.findElement(By.xpath("//span[@id='cstSearch']")).click();*/
		Thread.sleep(2000);
		new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(Custdetailswebe.icon_delete));
		System.out.println("The Customer ID IS :::::::::: ======= "+Custdetailswebe.attbtn_name.getText());
		Custdetailswebe.icon_delete.click();
		Thread.sleep(2000);
		driver.close();
	}

	@Then("^Customer detail should be displayed$")
	public void CustomerDetails_Displayed_Successfully() throws Throwable {

	}
}
