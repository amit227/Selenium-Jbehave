package com.hsbc.sfe.teller.stepDefinitions;

import org.openqa.selenium.WebDriver;

import com.hsbc.sfe.teller.Helpers.InitDriver;
import com.hsbc.sfe.teller.elements_Factory.CustomerDetailsPopup_elements;
import com.hsbc.sfe.teller.elements_Factory.CustomerSearchPopUp_Elements;
import com.hsbc.sfe.teller.elements_Factory.LandingPage_Elements;
import com.hsbc.sfe.teller.elements_Factory.LoginPage_Elements;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Common_Anno {
	static WebDriver driver = InitDriver.driver();
	public static LandingPage_Elements Landingwebe = LandingPage_Elements.getinstance(driver);
	public static LoginPage_Elements Loginwebe = LoginPage_Elements.getinstance(driver);
	public static CustomerDetailsPopup_elements Custdetailswebe = CustomerDetailsPopup_elements.getinstance(driver);
	public static CustomerSearchPopUp_Elements CustSearchwebe = CustomerSearchPopUp_Elements.getinstance(driver);
	
	@Given("^User opens the HSBC URL$")
	public void Login_Into_Application(){
		driver.get("http://cd499.p2g.netd2.hk.hsbc/1/2/");
		driver.manage().window().maximize();
		
	}
	
	@Given("^User is logged in$")
	public void User_Into_Application(){
		if(Loginwebe.btn_LogIn.isDisplayed()){
			System.out.println("https://cd499.p2g.netd2.hk.hsbc/1/2/");
		} else {
			driver.navigate().to("");
			driver.manage().window().maximize();
		}
	}
	@When("^User Navigate to LogIn Page$")
	public void user_Navigate_to_LogIn_Page() throws Throwable {
		if(Loginwebe.btn_LogIn.isDisplayed()){
			System.out.println("https://cd499.p2g.netd2.hk.hsbc/1/2/");
		} else {
			driver.navigate().to("https://cd499.p2g.netd2.hk.hsbc/1/2/");
			driver.manage().window().maximize();
		}
	}	
	@When("^User is on Home Page$")
	public void user_is_on_Home_Page() throws Throwable {
		if(Loginwebe.btn_LogIn.isDisplayed()){
			System.out.println("https://cd499.p2g.netd2.hk.hsbc/1/2/");
		} else {
			driver.navigate().to("https://cd499.p2g.netd2.hk.hsbc/1/2/");
			driver.manage().window().maximize();
		}
	}	
}
