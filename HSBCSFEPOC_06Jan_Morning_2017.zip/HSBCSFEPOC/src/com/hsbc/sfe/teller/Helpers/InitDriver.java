package com.hsbc.sfe.teller.Helpers;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import com.hsbc.sfe.teller.elements_Factory.LandingPage_Elements;

public class InitDriver {

    public static WebDriver driver;
    public static LandingPage_Elements Landingwebe;

    static {
        initDrivers();

    }

    public static void initDrivers() {
    	System.setProperty("webdriver.ie.driver", "Drivers/IEDriverServer.exe");

       InitDriver.driver = new InternetExplorerDriver();
    	//InitDriver.driver = new FirefoxDriver();
    }

    public static WebDriver driver() {
        return InitDriver.driver;
    }
}
 
