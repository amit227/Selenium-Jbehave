package com.hsbc.sfe.teller.elements_Factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CustomerDetailsPopup_elements {
	
	
	@FindBy(xpath="//i[@class='icon-delete']")
	public WebElement icon_delete;
	
	@FindBy(xpath="//span[@data-dojo-attach-point='_name']")
	public WebElement attbtn_name;
	
	static CustomerDetailsPopup_elements INSTANCE;
	public static CustomerDetailsPopup_elements getinstance(WebDriver driver) {
		return INSTANCE = PageFactory.initElements(driver, CustomerDetailsPopup_elements.class);
	}

}
