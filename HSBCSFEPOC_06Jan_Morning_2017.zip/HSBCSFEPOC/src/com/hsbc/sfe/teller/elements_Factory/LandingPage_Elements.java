package com.hsbc.sfe.teller.elements_Factory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LandingPage_Elements {
	
	
	@FindBy(id="CUS")
	public WebElement lnk_Customer;
	
	@FindBy(xpath="//span[@title='Customer Overview']")
	public WebElement lnk_customerTitle;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	
	static LandingPage_Elements INSTANCE;
	public static LandingPage_Elements getinstance(WebDriver driver) {
		return INSTANCE = PageFactory.initElements(driver, LandingPage_Elements.class);
	}
	

}
