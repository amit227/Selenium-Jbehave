package com.hsbc.sfe.teller.elements_Factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CustomerSearchPopUp_Elements {
	
	
	@FindBy(xpath="(//div[@class='HUBAccountdiv'])[1]//div[@class='dijitReset dijitInputField dijitInputContainer activeInput']//input[@title='Branch Code']")
	public WebElement txt_BranchCode;
	
	@FindBy(xpath="//span[@title='Customer Overview']")
	public WebElement link_customerTitle;
	
	@FindBy(xpath=("//span[@id='cstSearch']"))
	public WebElement btn_Search;
	
	@FindBy(xpath=("(//div[@class='HUBAccountdiv'])[1]//div[@class='dijitReset dijitInputField dijitInputContainer activeInput']//input[@title='Serial Number']"))
	public WebElement txt_Serial_Number;
	
	
	
		
	
	static CustomerSearchPopUp_Elements INSTANCE;
	public static CustomerSearchPopUp_Elements getinstance(WebDriver driver) {
		return INSTANCE = PageFactory.initElements(driver, CustomerSearchPopUp_Elements.class);
	}
}
