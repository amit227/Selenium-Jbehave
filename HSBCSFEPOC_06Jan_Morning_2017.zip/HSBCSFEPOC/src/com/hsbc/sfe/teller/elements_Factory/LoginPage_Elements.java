package com.hsbc.sfe.teller.elements_Factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage_Elements {
	
	
	
	@FindBy(id="userID")
	public WebElement txt_UserID;
	
	@FindBy(id="password")
	public WebElement txt_Password;
	
	@FindBy(xpath="//input[@value='Log in']")
	public WebElement btn_LogIn;
	
	@FindBy(xpath="//input[@name='cmd_signonSubmit']")
	public WebElement btn_Login2;
	
	@FindBy(xpath="//input[@name='cmd_continueToHomePage']")
	public WebElement btn_continueToHomePage;
	
	
	
	
	static LoginPage_Elements INSTANCE;
	public static LoginPage_Elements getinstance(WebDriver driver) {
		return INSTANCE = PageFactory.initElements(driver, LoginPage_Elements.class);
	}

}
