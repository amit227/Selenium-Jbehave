
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

public class Sqlselection {
	public static void main(String a[]) throws SQLException, IOException {
		String dbURL = "jdbc:sqlserver://10.66.34.152:61295;instance=./SQLEXPRESS;databaseName=IRIS_FOR_QA";
		String user = "fintracuser";
		String pass = "@#ewSDcx4";
		String sqlFile = "C:\\Users\\310028\\Desktop\\Fircosoft\\DatabaseView-FieldMappingSheet\\ViewDataSql_V1.14.sql";
		String orderId = "700026535";
		Connection conn = DriverManager.getConnection(dbURL, user, pass);
		if (conn != null) {
			DatabaseMetaData dm = (DatabaseMetaData) conn.getMetaData();
			System.out.println("Driver name: " + dm.getDriverName());
			System.out.println("Driver version: " + dm.getDriverVersion());
			System.out.println("Product name: " + dm.getDatabaseProductName());
			System.out.println("Product version: " + dm.getDatabaseProductVersion());
			Statement stmt = conn.createStatement();

			/*
			 * BufferedReader in = new BufferedReader(new FileReader(sqlFile));
			 * String str; StringBuffer sb = new StringBuffer(); while ((str =
			 * in.readLine()) != null) { sb.append(str + "\n "); } sb.append(
			 * " where P.OrderId = '" + orderId + "'");
			 * 
			 * System.out.println("SQL " + sb.toString());
			 * 
			 * in.close();
			 */

			String[] result = new String[20];

			ResultSet rs = stmt.executeQuery("SELECT TOP 1 * FROM EAS.Payment");
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			 int i =1;

			System.out.println(rs);
			if (result != null) {
				System.out.println("inside if");
				while (rs.next()) {
					for(i=1;i<=columnCount;i++)
					System.out.println(rs.getString(i));

				}
			}

		}
	}

}

/*
 * public static void main(String[] args) { try {
 * Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
 * 
 * String userName = "fintracuser"; String password = "@#ewSDcx4"; String url =
 * "jdbc:sqlserver://10.66.34.152:61295;instance=./SQLEXPRESS;databaseName=IRIS_FOR_QA";
 * Connection con = DriverManager.getConnection(url, userName, password);
 * 
 * System.out.println(con); Statement s1 = con.createStatement(); //
 * con.prepareStatement(arg0, arg1) ResultSet rs = s1.executeQuery(
 * "SELECT TOP 1 * FROM EAS.Payment"); String[] result = new String[20];
 * if(rs!=null){ while (rs.next()){ for(int i = 0; i <result.length ;i++) {
 * for(int j = 0; j <result.length;j++) { result[j]=rs.getString(i);
 * System.out.println(result[j]); } } } }
 * 
 * //String result = new result[20];
 * 
 * } catch (Exception e) { e.printStackTrace(); } }
 */
