
public class JsonPlayTest {

	
	public static void main(String a[])
	{
		Employee emp = new Employee();
		emp.setEmpno(1);
		emp.setName("Amit");
		emp.setSalary(20000.0);
		
		System.out.println(JsonUtils.converJavaToJson(emp));
		System.out.println(String.format("facebook.come","Amit"));
/*Employee emp1 = JsonUtils.convertJsonToJava(JsonUtils.converJavaToJson(emp),Employee.class);
		System.out.println(emp1.getEmpno() + emp1.getName() + emp1.getSalary());*/
	}
	
}
