import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.couchbase.client.core.CouchbaseException;
import com.couchbase.client.deps.io.netty.handler.timeout.TimeoutException;
import com.couchbase.client.java.Bucket;
import com.couchbase.client.java.CouchbaseBucket;
import com.couchbase.client.java.CouchbaseCluster;
import com.couchbase.client.java.env.CouchbaseEnvironment;
import com.couchbase.client.java.env.DefaultCouchbaseEnvironment;

import japa.parser.ParseException;

public class CouchbaseConnection {
	static CouchbaseCluster couchbaseCluster = null;
	Bucket couchbaseBucket=null;

	public static void main(String a[])
			throws TimeoutException, CouchbaseException, IOException, ParseException, Exception {

		CouchbaseConnection connection = new CouchbaseConnection();
		//PropertyReader fileReader = PropertyReader.getInstance();
		//fileReader.initializeCouchBaseConstants();
		CouchbaseEnvironment env = DefaultCouchbaseEnvironment.builder().connectTimeout(10000).build();
		String hostName = "";
		// Uncomment when connecting to a cluster
		//List<String> hostNames = "";
		String bucketName ="travel-sample";
		CouchbaseConnection.couchbaseCluster = CouchbaseCluster.create(env,"couchbase://127.0.0.1:8091");
		connection.couchbaseBucket = couchbaseCluster.openBucket(bucketName);
	}

}
