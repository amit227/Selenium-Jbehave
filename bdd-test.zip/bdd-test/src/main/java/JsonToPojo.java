
import java.io.File;  
import java.io.IOException;  
import java.net.MalformedURLException;  
import java.net.URL;  
import org.jsonschema2pojo.DefaultGenerationConfig;  
import org.jsonschema2pojo.GenerationConfig;  
import org.jsonschema2pojo.Jackson2Annotator;  
import org.jsonschema2pojo.SchemaGenerator;  
import org.jsonschema2pojo.SchemaMapper;  
import org.jsonschema2pojo.SchemaStore;  
import org.jsonschema2pojo.SourceType;  
import org.jsonschema2pojo.rules.RuleFactory;  
import com.sun.codemodel.JCodeModel;  
public class JsonToPojo {  
     /**  
      * @param args  
      */  
     public static void main(String[] args) {  
          String packageName="serenityTesting.responseJson";  
       //  C:\Users\310053\Serenity API\bdd-test\src\test\resources\stories
          
          File inputJson = new File("C:\\Users\\310053\\Serenity API\\bdd-test\\src\\test\\resources\\stories\\FilteringAPI_TC9_Response.json");
 	     /*If file gets created then the createNewFile() 
 	      * method would return true or if the file is 
 	      * already present it would return false
 	      */
              try {
				boolean fvar = inputJson.createNewFile();
				System.out.println(inputJson.getAbsolutePath());
				System.out.println("88888888888" + fvar);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
              
      //    File inputJson= new File("."+File.separator+"input.json");  
          File outputPojoDirectory=new File("C:\\Users\\310053\\Serenity API\\bdd-test\\src\\test\\java\\serenityTesting\\responseJson");  
          outputPojoDirectory.mkdirs();  
          try {  
               new JsonToPojo().convert2JSON(inputJson.toURI().toURL(), outputPojoDirectory, packageName, inputJson.getName().replace(".json", ""));  
          } catch (IOException e) {  
               // TODO Auto-generated catch block  
               System.out.println("Encountered issue while converting to pojo: "+e.getMessage());  
               e.printStackTrace();  
          }  
     }  
     public void convert2JSON(URL inputJson, File outputPojoDirectory, String packageName, String className) throws IOException{  
          JCodeModel codeModel = new JCodeModel();  
          URL source = inputJson;  
          GenerationConfig config = new DefaultGenerationConfig() {  
          @Override  
          public boolean isGenerateBuilders() { // set config option by overriding method  
              return true;  
          }  
          public SourceType getSourceType(){  
      return SourceType.JSON;  
    }  
          };  
          SchemaMapper mapper = new SchemaMapper(new RuleFactory(config, new Jackson2Annotator(config), new SchemaStore()), new SchemaGenerator());  
          mapper.generate(codeModel, className, packageName, source);  
          codeModel.build(outputPojoDirectory);  
     }  
}