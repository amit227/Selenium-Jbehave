/*

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.google.common.collect.Table.Cell;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.spi.json.JacksonJsonNodeJsonProvider;
import com.jayway.jsonpath.spi.mapper.JacksonMappingProvider;

public class FUFValidationTest {

	public static void main(String[] args) throws InvalidFormatException,
			IOException, SQLException {

		String testScenariosExcelPath = "C:\\Users\\310028\\Desktop\\Fircosoft\\FUFValidationAutomation\\FUFValidationTest.xlsx";
		String testResultFilePath = "C:\\Users\\310028\\Desktop\\Fircosoft\\FUFValidationAutomation\\FUFValidationTestResult.xlsx";
		String paymentJSONFilePath = "C:\\Users\\310028\\Desktop\\Fircosoft\\FUFValidationAutomation\\InputPaymentJSON.json";
		String screeninResponseFilePath = "C:\\Users\\310028\\Desktop\\Fircosoft\\FUFValidationAutomation\\ScreeningResponse.json";
		
		// Read all the test scenarios from Excel sheet
		List<List<String>> testScenariosFromExcel = ReadFromExcel(testScenariosExcelPath);

		// Populate Database base values
		testScenariosFromExcel = GetDBValues(testScenariosFromExcel);

		// Populate input Payment JSON values
		testScenariosFromExcel = GetPaymentJSONValues(testScenariosFromExcel,
				paymentJSONFilePath);

		// Populate with FUF values
		testScenariosFromExcel = GetFUFValues(testScenariosFromExcel,
				screeninResponseFilePath);

		// Write everything in excel file
		GenerateTestResult(testScenariosFromExcel, testResultFilePath);

	}

	public static List<List<String>> ReadFromExcel(String excelFilePath)
			throws InvalidFormatException, IOException {
		List<List<String>> testScenariosFromExcel = new ArrayList<List<String>>();

		// Read the test scenarios from Excel sheet
		String testScenarioExcel = excelFilePath;
		File testScenarioFile = new File(testScenarioExcel);

		XSSFWorkbook testScenarioWorkBook = new XSSFWorkbook(testScenarioFile);
		XSSFSheet testScenarioWorkSheet = testScenarioWorkBook
				.getSheet("FUFValidation");

		int rowCnt = testScenarioWorkSheet.getPhysicalNumberOfRows();
		int colCnt = testScenarioWorkSheet.getRow(0).getPhysicalNumberOfCells();
		DataFormatter formatter = new DataFormatter();
		for (int i = 0; i < colCnt; i++) {
			List<String> columnValue = new ArrayList<String>();

			for (int j = 0; j < rowCnt; j++) {
				XSSFRow row = testScenarioWorkSheet.getRow(j);
				columnValue.add(formatter.formatCellValue(row.getCell(i)));
			}
			testScenariosFromExcel.add(columnValue);
		}

		return testScenariosFromExcel;

	}

	public static List<List<String>> GetDBValues(
			List<List<String>> testScenariosFromExcel) throws SQLException,
			IOException {
		String dbURL = "jdbc:sqlserver://10.66.34.152:61295;instance=./SQLEXPRESS;databaseName=IRIS_FOR_QA";
		String user = "fintracuser";
		String pass = "@#ewSDcx4";
		String sqlFile = "C:\\Users\\310028\\Desktop\\Fircosoft\\DatabaseView-FieldMappingSheet\\ViewDataSql_V1.14.sql";
		String orderId = "700026535";
		Connection conn = DriverManager.getConnection(dbURL, user, pass);
		if (conn != null) {
			DatabaseMetaData dm = (DatabaseMetaData) conn.getMetaData();
			System.out.println("Driver name: " + dm.getDriverName());
			System.out.println("Driver version: " + dm.getDriverVersion());
			System.out.println("Product name: " + dm.getDatabaseProductName());
			System.out.println("Product version: "
					+ dm.getDatabaseProductVersion());
			Statement stmt = conn.createStatement();

			BufferedReader in = new BufferedReader(new FileReader(sqlFile));
			String str;
			StringBuffer sb = new StringBuffer();
			while ((str = in.readLine()) != null) {
				sb.append(str + "\n ");
			}
			sb.append(" where P.OrderId = '" + orderId + "'");

			System.out.println("SQL " + sb.toString());

			in.close();
			
			List<String> tableColumn_Excel = testScenariosFromExcel.get(2);
			ResultSet rs = stmt.executeQuery("Select * from V_PaymentAndEntityDetails where OrderId = '700026535'");
			int i = 1;
			while (rs.next()) {

				for (String tableColumnCellValue_Excel : tableColumn_Excel) {
					if(!tableColumnCellValue_Excel.equals("ColumnName"))
					{
						System.out.println("cellvalue"
								+ tableColumnCellValue_Excel.replace("[", "")
										.replace("]", ""));
						String tableValueFromDB_Excel = rs
								.getString(tableColumnCellValue_Excel.replace("[",
										"").replace("]", ""));
						testScenariosFromExcel.get(3)
								.set(i, tableValueFromDB_Excel);
						i++;
					}
				}
			}
		}
		return testScenariosFromExcel;
	}

	public static List<List<String>> GetPaymentJSONValues(
			List<List<String>> testScenariosFromExcel, String inputJsonFilePath) {
		String inputJson = getInputJson(inputJsonFilePath);

		Configuration config = Configuration.builder()
				.jsonProvider(new JacksonJsonNodeJsonProvider())
				.mappingProvider(new JacksonMappingProvider()).build();

		DocumentContext newJson = null;
		newJson = JsonPath.using(config).parse(inputJson);

		Object document = Configuration.defaultConfiguration().jsonProvider()
				.parse(newJson.jsonString());
		
		List<String> tableColumn_Excel = testScenariosFromExcel.get(4);
		int i = 1;
		String tableValueFromDB_Excel = "";
		for (String tableColumnCellValue_Excel : tableColumn_Excel) {
			if(!tableColumnCellValue_Excel.equals("InputJSONPath"))
			{
				try
				{
					tableValueFromDB_Excel= JsonPath.read(document,
					tableColumnCellValue_Excel).toString();
				}
				catch(Exception ex) {
					tableValueFromDB_Excel = "Field Not Found";
					System.out.println("field not found exception trace" + ex);
					ex.printStackTrace();
				}
			testScenariosFromExcel.get(5).set(i, tableValueFromDB_Excel);
			
			// Comparison 
			if(tableValueFromDB_Excel.equals(testScenariosFromExcel.get(3).get(i)))
			{
				testScenariosFromExcel.get(8).set(i, "Passed");
			}
			else{
				testScenariosFromExcel.get(8).set(i, "Failed");
			}
			i++;
			}
		}
		return testScenariosFromExcel;
	}

	public static List<List<String>> GetFUFValues(
			List<List<String>> testScenariosFromExcel,
			String responseJsonFilePath) {
		String responseJson = getInputJson(responseJsonFilePath);
		String fufMsgPath = "$.caseMgmtResponse.messages.message.messageData";

		Configuration config = Configuration.builder()
				.jsonProvider(new JacksonJsonNodeJsonProvider())
				.mappingProvider(new JacksonMappingProvider()).build();

		DocumentContext newJson = null;
		newJson = JsonPath.using(config).parse(responseJson);

		Object document = Configuration.defaultConfiguration().jsonProvider()
				.parse(newJson.jsonString());

		String fufMessage = JsonPath.read(document, fufMsgPath);
		
		List<String> tableColumn_Excel = testScenariosFromExcel.get(6);
		int i = 1;
		for (String tableColumnCellValue_Excel : tableColumn_Excel) {
			if(!tableColumnCellValue_Excel.equals("FUF Path"))
			{
			String tableValueFromDB_Excel = null;
			int startPos = fufMessage.indexOf(tableColumnCellValue_Excel);
			if (startPos > 0) {
				int endPos = fufMessage.indexOf("\n", startPos);
				String fieldValue = fufMessage.substring(startPos, endPos);
				// System.out.println(fieldValue);

				tableValueFromDB_Excel = fieldValue.substring(fieldValue
						.indexOf("]") + 1).trim();
			} else {

				tableValueFromDB_Excel = "FieldNotFound";
			}
			testScenariosFromExcel.get(7).set(i, tableValueFromDB_Excel);
			
			String testResult = "Failed";
			// Comparison 
			if(tableValueFromDB_Excel.equals(testScenariosFromExcel.get(5).get(i)))
			{
				
				testScenariosFromExcel.get(9).set(i, "Passed");
			}
			else{
				
				testScenariosFromExcel.get(9).set(i, "Failed");
			}

			if(testScenariosFromExcel.get(8).get(i).equals("Passed") && testScenariosFromExcel.get(9).get(i).equals("Passed"))
			{
				
				testScenariosFromExcel.get(10).set(i, "Passed");
			}
			else{ 
				testScenariosFromExcel.get(10).set(i, "Failed");
			}
			i++;
			}
		}

		return testScenariosFromExcel;
	}

	public static void GenerateTestResult(
			List<List<String>> testScenariosFromExcel,
			String testResultExcelFilePath) throws EncryptedDocumentException, InvalidFormatException, IOException {
		     
		File file = new File(testResultExcelFilePath);
		
		Workbook wb = WorkbookFactory.create(file);

		org.apache.poi.ss.usermodel.Sheet s = wb.getSheetAt(0) ;
				
		int rowCnt = testScenariosFromExcel.get(0).size();
		int colCnt = testScenariosFromExcel.size();
	
		for(int i = 0; i < rowCnt ; i++)
		{
			Row r=((XSSFSheet) s).createRow(i);
			
			for(int j=0;j<colCnt;j++)
			{
				String toWrite = testScenariosFromExcel.get(j).get(i);
				r.createCell(j).setCellValue(toWrite);
			}
		}
					
        FileOutputStream outputStream = new FileOutputStream("FUFValidationTestResult.xlsx");
        wb.write(outputStream);
        wb.close();
        outputStream.close();

		
		
	}

	public static String getInputJson(String filePath) {

		String strFile = filePath;
		String inputJson = null;
		File f = new File(strFile);
		BufferedReader br = null;
		FileReader fr = null;
		StringBuffer strBuffJson = new StringBuffer();
		if (f.exists()) {
			String sCurrentLine;
			try {
				fr = new FileReader(f);
				br = new BufferedReader(fr);
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			try {
				while ((sCurrentLine = br.readLine()) != null) {
					strBuffJson.append(sCurrentLine + "\n");
				}

				inputJson = strBuffJson.toString();

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {

				try {

					if (br != null)
						br.close();

					if (fr != null)
						fr.close();

				} catch (IOException ex) {

					ex.printStackTrace();

				}
			}

			return inputJson;

		}

		return null;

	}

}
*/