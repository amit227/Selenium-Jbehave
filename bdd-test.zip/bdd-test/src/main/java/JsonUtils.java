import java.io.IOException;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

public class JsonUtils {
	private static ObjectMapper mapper;
	static 
	{
		mapper =new ObjectMapper();
		
	}
	
	public static String converJavaToJson(Object obj)
	{
		String jsonResult = "";
		
		try {
			jsonResult = mapper.writeValueAsString(obj);
		} 
		
		catch (JsonGenerationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return jsonResult;
	}
	
	public static <T> T convertJsonToJava(String jsonString , Class<T> cls)
	{
		T javaObjectResult = null;
		try {
			javaObjectResult = mapper.readValue(jsonString, cls);
		} 
		catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return javaObjectResult;
	}
	

}
