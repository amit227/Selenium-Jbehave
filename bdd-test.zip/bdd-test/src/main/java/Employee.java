import org.codehaus.jackson.annotate.JsonPropertyOrder;

@JsonPropertyOrder(value= {"Empno","name","Salary"})
public class Employee {
	int Empno;
	String name;
	Double Salary;
	public int getEmpno() {
		return Empno;
	}
	public void setEmpno(int empno) {
		Empno = empno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getSalary() {
		return Salary;
	}
	public void setSalary(Double salary) {
		Salary = salary;
	}
	
	
	

}
