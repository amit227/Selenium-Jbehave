/*import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class jsonReader {
 RestTemplate restTemplate = new RestTemplate();
	
	ObjectMapper objectMapper = new ObjectMapper();
	String request = "{\"some\":\"value\"}";
	Map<String, String> dataMap = objectMapper.readValue(request, Map.class);
	ResponseEntity<Map> responseEntity = restTemplate.postForEntity("https://someurl", dataMap, Map.class);
	 Map  response =responseEntity.getBody();
	
	
}
		*/