


import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "type",
    "name",
    "address",
    "contact",
    "individual",
    "company",
    "misc",
    "id",
    "individualInfo",
    "contactInfo"
})
public class Party {

    @JsonProperty("type")
    private String type;
    @JsonProperty("name")
    private Name name;
    @JsonProperty("address")
    private Address_ address;
    @JsonProperty("contact")
    private Contact contact;
    @JsonProperty("individual")
    private Individual individual;
    @JsonProperty("company")
    private Company company;
    @JsonProperty("misc")
    private Misc misc;
    @JsonProperty("id")
    private String id;
    @JsonProperty("individualInfo")
    private IndividualInfo individualInfo;
    @JsonProperty("contactInfo")
    private ContactInfo contactInfo;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    public Party withType(String type) {
        this.type = type;
        return this;
    }

    @JsonProperty("name")
    public Name getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(Name name) {
        this.name = name;
    }

    public Party withName(Name name) {
        this.name = name;
        return this;
    }

    @JsonProperty("address")
    public Address_ getAddress() {
        return address;
    }

    @JsonProperty("address")
    public void setAddress(Address_ address) {
        this.address = address;
    }

    public Party withAddress(Address_ address) {
        this.address = address;
        return this;
    }

    @JsonProperty("contact")
    public Contact getContact() {
        return contact;
    }

    @JsonProperty("contact")
    public void setContact(Contact contact) {
        this.contact = contact;
    }

    public Party withContact(Contact contact) {
        this.contact = contact;
        return this;
    }

    @JsonProperty("individual")
    public Individual getIndividual() {
        return individual;
    }

    @JsonProperty("individual")
    public void setIndividual(Individual individual) {
        this.individual = individual;
    }

    public Party withIndividual(Individual individual) {
        this.individual = individual;
        return this;
    }

    @JsonProperty("company")
    public Company getCompany() {
        return company;
    }

    @JsonProperty("company")
    public void setCompany(Company company) {
        this.company = company;
    }

    public Party withCompany(Company company) {
        this.company = company;
        return this;
    }

    @JsonProperty("misc")
    public Misc getMisc() {
        return misc;
    }

    @JsonProperty("misc")
    public void setMisc(Misc misc) {
        this.misc = misc;
    }

    public Party withMisc(Misc misc) {
        this.misc = misc;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public Party withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("individualInfo")
    public IndividualInfo getIndividualInfo() {
        return individualInfo;
    }

    @JsonProperty("individualInfo")
    public void setIndividualInfo(IndividualInfo individualInfo) {
        this.individualInfo = individualInfo;
    }

    public Party withIndividualInfo(IndividualInfo individualInfo) {
        this.individualInfo = individualInfo;
        return this;
    }

    @JsonProperty("contactInfo")
    public ContactInfo getContactInfo() {
        return contactInfo;
    }

    @JsonProperty("contactInfo")
    public void setContactInfo(ContactInfo contactInfo) {
        this.contactInfo = contactInfo;
    }

    public Party withContactInfo(ContactInfo contactInfo) {
        this.contactInfo = contactInfo;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Party withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(type).append(name).append(address).append(contact).append(individual).append(company).append(misc).append(id).append(individualInfo).append(contactInfo).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Party) == false) {
            return false;
        }
        Party rhs = ((Party) other);
        return new EqualsBuilder().append(type, rhs.type).append(name, rhs.name).append(address, rhs.address).append(contact, rhs.contact).append(individual, rhs.individual).append(company, rhs.company).append(misc, rhs.misc).append(id, rhs.id).append(individualInfo, rhs.individualInfo).append(contactInfo, rhs.contactInfo).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
