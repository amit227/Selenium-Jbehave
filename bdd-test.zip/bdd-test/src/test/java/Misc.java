


import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "status",
    "individualFlag",
    "branchCode",
    "branchType",
    "salesforceAMLRiskRating",
    "owningLegalEntityName",
    "relationshipType"
})
public class Misc {

    @JsonProperty("status")
    private String status;
    @JsonProperty("individualFlag")
    private String individualFlag;
    @JsonProperty("branchCode")
    private String branchCode;
    @JsonProperty("branchType")
    private String branchType;
    @JsonProperty("salesforceAMLRiskRating")
    private String salesforceAMLRiskRating;
    @JsonProperty("owningLegalEntityName")
    private String owningLegalEntityName;
    @JsonProperty("relationshipType")
    private String relationshipType;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("status")
    public void setStatus(String status) {
        this.status = status;
    }

    public Misc withStatus(String status) {
        this.status = status;
        return this;
    }

    @JsonProperty("individualFlag")
    public String getIndividualFlag() {
        return individualFlag;
    }

    @JsonProperty("individualFlag")
    public void setIndividualFlag(String individualFlag) {
        this.individualFlag = individualFlag;
    }

    public Misc withIndividualFlag(String individualFlag) {
        this.individualFlag = individualFlag;
        return this;
    }

    @JsonProperty("branchCode")
    public String getBranchCode() {
        return branchCode;
    }

    @JsonProperty("branchCode")
    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }

    public Misc withBranchCode(String branchCode) {
        this.branchCode = branchCode;
        return this;
    }

    @JsonProperty("branchType")
    public String getBranchType() {
        return branchType;
    }

    @JsonProperty("branchType")
    public void setBranchType(String branchType) {
        this.branchType = branchType;
    }

    public Misc withBranchType(String branchType) {
        this.branchType = branchType;
        return this;
    }

    @JsonProperty("salesforceAMLRiskRating")
    public String getSalesforceAMLRiskRating() {
        return salesforceAMLRiskRating;
    }

    @JsonProperty("salesforceAMLRiskRating")
    public void setSalesforceAMLRiskRating(String salesforceAMLRiskRating) {
        this.salesforceAMLRiskRating = salesforceAMLRiskRating;
    }

    public Misc withSalesforceAMLRiskRating(String salesforceAMLRiskRating) {
        this.salesforceAMLRiskRating = salesforceAMLRiskRating;
        return this;
    }

    @JsonProperty("owningLegalEntityName")
    public String getOwningLegalEntityName() {
        return owningLegalEntityName;
    }

    @JsonProperty("owningLegalEntityName")
    public void setOwningLegalEntityName(String owningLegalEntityName) {
        this.owningLegalEntityName = owningLegalEntityName;
    }

    public Misc withOwningLegalEntityName(String owningLegalEntityName) {
        this.owningLegalEntityName = owningLegalEntityName;
        return this;
    }

    @JsonProperty("relationshipType")
    public String getRelationshipType() {
        return relationshipType;
    }

    @JsonProperty("relationshipType")
    public void setRelationshipType(String relationshipType) {
        this.relationshipType = relationshipType;
    }

    public Misc withRelationshipType(String relationshipType) {
        this.relationshipType = relationshipType;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Misc withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(status).append(individualFlag).append(branchCode).append(branchType).append(salesforceAMLRiskRating).append(owningLegalEntityName).append(relationshipType).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Misc) == false) {
            return false;
        }
        Misc rhs = ((Misc) other);
        return new EqualsBuilder().append(status, rhs.status).append(individualFlag, rhs.individualFlag).append(branchCode, rhs.branchCode).append(branchType, rhs.branchType).append(salesforceAMLRiskRating, rhs.salesforceAMLRiskRating).append(owningLegalEntityName, rhs.owningLegalEntityName).append(relationshipType, rhs.relationshipType).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
