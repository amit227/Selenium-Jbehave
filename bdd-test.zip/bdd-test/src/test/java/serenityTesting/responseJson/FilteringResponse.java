
package serenityTesting.responseJson;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "versionTag",
    "messageID",
    "unit",
    "businessUnit",
    "applicationCode",
    "bypass",
    "bypassRecovery",
    "messageStatus",
    "statusLabel",
    "statusComment",
    "statusOwner",
    "messageChecksum",
    "systemID",
    "alertsDetail",
    "messageData"
})
public class FilteringResponse {

    @JsonProperty("versionTag")
    private String versionTag;
    @JsonProperty("messageID")
    private String messageID;
    @JsonProperty("unit")
    private String unit;
    @JsonProperty("businessUnit")
    private String businessUnit;
    @JsonProperty("applicationCode")
    private String applicationCode;
    @JsonProperty("bypass")
    private String bypass;
    @JsonProperty("bypassRecovery")
    private String bypassRecovery;
    @JsonProperty("messageStatus")
    private String messageStatus;
    @JsonProperty("statusLabel")
    private String statusLabel;
    @JsonProperty("statusComment")
    private String statusComment;
    @JsonProperty("statusOwner")
    private String statusOwner;
    @JsonProperty("messageChecksum")
    private String messageChecksum;
    @JsonProperty("systemID")
    private String systemID;
    @JsonProperty("alertsDetail")
    private String alertsDetail;
    @JsonProperty("messageData")
    private String messageData;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("versionTag")
    public String getVersionTag() {
        return versionTag;
    }

    @JsonProperty("versionTag")
    public void setVersionTag(String versionTag) {
        this.versionTag = versionTag;
    }

    public FilteringResponse withVersionTag(String versionTag) {
        this.versionTag = versionTag;
        return this;
    }

    @JsonProperty("messageID")
    public String getMessageID() {
        return messageID;
    }

    @JsonProperty("messageID")
    public void setMessageID(String messageID) {
        this.messageID = messageID;
    }

    public FilteringResponse withMessageID(String messageID) {
        this.messageID = messageID;
        return this;
    }

    @JsonProperty("unit")
    public String getUnit() {
        return unit;
    }

    @JsonProperty("unit")
    public void setUnit(String unit) {
        this.unit = unit;
    }

    public FilteringResponse withUnit(String unit) {
        this.unit = unit;
        return this;
    }

    @JsonProperty("businessUnit")
    public String getBusinessUnit() {
        return businessUnit;
    }

    @JsonProperty("businessUnit")
    public void setBusinessUnit(String businessUnit) {
        this.businessUnit = businessUnit;
    }

    public FilteringResponse withBusinessUnit(String businessUnit) {
        this.businessUnit = businessUnit;
        return this;
    }

    @JsonProperty("applicationCode")
    public String getApplicationCode() {
        return applicationCode;
    }

    @JsonProperty("applicationCode")
    public void setApplicationCode(String applicationCode) {
        this.applicationCode = applicationCode;
    }

    public FilteringResponse withApplicationCode(String applicationCode) {
        this.applicationCode = applicationCode;
        return this;
    }

    @JsonProperty("bypass")
    public String getBypass() {
        return bypass;
    }

    @JsonProperty("bypass")
    public void setBypass(String bypass) {
        this.bypass = bypass;
    }

    public FilteringResponse withBypass(String bypass) {
        this.bypass = bypass;
        return this;
    }

    @JsonProperty("bypassRecovery")
    public String getBypassRecovery() {
        return bypassRecovery;
    }

    @JsonProperty("bypassRecovery")
    public void setBypassRecovery(String bypassRecovery) {
        this.bypassRecovery = bypassRecovery;
    }

    public FilteringResponse withBypassRecovery(String bypassRecovery) {
        this.bypassRecovery = bypassRecovery;
        return this;
    }

    @JsonProperty("messageStatus")
    public String getMessageStatus() {
        return messageStatus;
    }

    @JsonProperty("messageStatus")
    public void setMessageStatus(String messageStatus) {
        this.messageStatus = messageStatus;
    }

    public FilteringResponse withMessageStatus(String messageStatus) {
        this.messageStatus = messageStatus;
        return this;
    }

    @JsonProperty("statusLabel")
    public String getStatusLabel() {
        return statusLabel;
    }

    @JsonProperty("statusLabel")
    public void setStatusLabel(String statusLabel) {
        this.statusLabel = statusLabel;
    }

    public FilteringResponse withStatusLabel(String statusLabel) {
        this.statusLabel = statusLabel;
        return this;
    }

    @JsonProperty("statusComment")
    public String getStatusComment() {
        return statusComment;
    }

    @JsonProperty("statusComment")
    public void setStatusComment(String statusComment) {
        this.statusComment = statusComment;
    }

    public FilteringResponse withStatusComment(String statusComment) {
        this.statusComment = statusComment;
        return this;
    }

    @JsonProperty("statusOwner")
    public String getStatusOwner() {
        return statusOwner;
    }

    @JsonProperty("statusOwner")
    public void setStatusOwner(String statusOwner) {
        this.statusOwner = statusOwner;
    }

    public FilteringResponse withStatusOwner(String statusOwner) {
        this.statusOwner = statusOwner;
        return this;
    }

    @JsonProperty("messageChecksum")
    public String getMessageChecksum() {
        return messageChecksum;
    }

    @JsonProperty("messageChecksum")
    public void setMessageChecksum(String messageChecksum) {
        this.messageChecksum = messageChecksum;
    }

    public FilteringResponse withMessageChecksum(String messageChecksum) {
        this.messageChecksum = messageChecksum;
        return this;
    }

    @JsonProperty("systemID")
    public String getSystemID() {
        return systemID;
    }

    @JsonProperty("systemID")
    public void setSystemID(String systemID) {
        this.systemID = systemID;
    }

    public FilteringResponse withSystemID(String systemID) {
        this.systemID = systemID;
        return this;
    }

    @JsonProperty("alertsDetail")
    public String getAlertsDetail() {
        return alertsDetail;
    }

    @JsonProperty("alertsDetail")
    public void setAlertsDetail(String alertsDetail) {
        this.alertsDetail = alertsDetail;
    }

    public FilteringResponse withAlertsDetail(String alertsDetail) {
        this.alertsDetail = alertsDetail;
        return this;
    }

    @JsonProperty("messageData")
    public String getMessageData() {
        return messageData;
    }

    @JsonProperty("messageData")
    public void setMessageData(String messageData) {
        this.messageData = messageData;
    }

    public FilteringResponse withMessageData(String messageData) {
        this.messageData = messageData;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public FilteringResponse withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(versionTag).append(messageID).append(unit).append(businessUnit).append(applicationCode).append(bypass).append(bypassRecovery).append(messageStatus).append(statusLabel).append(statusComment).append(statusOwner).append(messageChecksum).append(systemID).append(alertsDetail).append(messageData).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof FilteringResponse) == false) {
            return false;
        }
        FilteringResponse rhs = ((FilteringResponse) other);
        return new EqualsBuilder().append(versionTag, rhs.versionTag).append(messageID, rhs.messageID).append(unit, rhs.unit).append(businessUnit, rhs.businessUnit).append(applicationCode, rhs.applicationCode).append(bypass, rhs.bypass).append(bypassRecovery, rhs.bypassRecovery).append(messageStatus, rhs.messageStatus).append(statusLabel, rhs.statusLabel).append(statusComment, rhs.statusComment).append(statusOwner, rhs.statusOwner).append(messageChecksum, rhs.messageChecksum).append(systemID, rhs.systemID).append(alertsDetail, rhs.alertsDetail).append(messageData, rhs.messageData).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
