
package serenityTesting.responseJson;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "responseStatus",
    "responseType",
    "filteringResponse",
    "errorInfo",
    "responseTime"
})
public class FilteringAPITC9Response {

    @JsonProperty("responseStatus")
    private String responseStatus;
    @JsonProperty("responseType")
    private String responseType;
    @JsonProperty("filteringResponse")
    private FilteringResponse filteringResponse;
    @JsonProperty("errorInfo")
    private ErrorInfo errorInfo;
    @JsonProperty("responseTime")
    private String responseTime;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("responseStatus")
    public String getResponseStatus() {
        return responseStatus;
    }

    @JsonProperty("responseStatus")
    public void setResponseStatus(String responseStatus) {
        this.responseStatus = responseStatus;
    }

    public FilteringAPITC9Response withResponseStatus(String responseStatus) {
        this.responseStatus = responseStatus;
        return this;
    }

    @JsonProperty("responseType")
    public String getResponseType() {
        return responseType;
    }

    @JsonProperty("responseType")
    public void setResponseType(String responseType) {
        this.responseType = responseType;
    }

    public FilteringAPITC9Response withResponseType(String responseType) {
        this.responseType = responseType;
        return this;
    }

    @JsonProperty("filteringResponse")
    public FilteringResponse getFilteringResponse() {
        return filteringResponse;
    }

    @JsonProperty("filteringResponse")
    public void setFilteringResponse(FilteringResponse filteringResponse) {
        this.filteringResponse = filteringResponse;
    }

    public FilteringAPITC9Response withFilteringResponse(FilteringResponse filteringResponse) {
        this.filteringResponse = filteringResponse;
        return this;
    }

    @JsonProperty("errorInfo")
    public ErrorInfo getErrorInfo() {
        return errorInfo;
    }

    @JsonProperty("errorInfo")
    public void setErrorInfo(ErrorInfo errorInfo) {
        this.errorInfo = errorInfo;
    }

    public FilteringAPITC9Response withErrorInfo(ErrorInfo errorInfo) {
        this.errorInfo = errorInfo;
        return this;
    }

    @JsonProperty("responseTime")
    public String getResponseTime() {
        return responseTime;
    }

    @JsonProperty("responseTime")
    public void setResponseTime(String responseTime) {
        this.responseTime = responseTime;
    }

    public FilteringAPITC9Response withResponseTime(String responseTime) {
        this.responseTime = responseTime;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public FilteringAPITC9Response withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(responseStatus).append(responseType).append(filteringResponse).append(errorInfo).append(responseTime).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof FilteringAPITC9Response) == false) {
            return false;
        }
        FilteringAPITC9Response rhs = ((FilteringAPITC9Response) other);
        return new EqualsBuilder().append(responseStatus, rhs.responseStatus).append(responseType, rhs.responseType).append(filteringResponse, rhs.filteringResponse).append(errorInfo, rhs.errorInfo).append(responseTime, rhs.responseTime).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
