package serenityTesting.steps;

import net.thucydides.core.annotations.Steps;

import org.jbehave.core.annotations.Aliases;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import serenityTesting.steps.serenity.EndUserGoogleSearchSteps;
import serenityTesting.steps.serenity.EndUserIRISSPWorkFlowSteps;
import serenityTesting.steps.serenity.EndUserSteps;

public class GoogleSearchSteps {

    @Steps
    EndUserGoogleSearchSteps endUser;

    @Given("User is on google home page")
    
    public void givenUserisOnGoogleHomePage() {
    	
    	endUser.isLaunchedGoogleHomePage();
    }

    @When("User enters some words to search")
    
    public void whenuserEnterWordTobeSearched() {
     
    	endUser.userEnterWordTobeSearched();
    }
    @When("User clicks on search button")
    public void whenUserClicksOnSearchButton()
    {
    	
    	endUser.userClicksOnSearchButton();
    }
    

    
    
    @Then("System should navigate to search result page having page title <title>")
    public void thenSystemShouldShowNavigateToTheSearchResultPage() {
      // PENDING
    	
    	endUser.systemShouldNavigateToSearchResultPage();
    }
}
    
   