package serenityTesting.steps;

import net.thucydides.core.annotations.Steps;

import org.jbehave.core.annotations.Aliases;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import serenityTesting.steps.serenity.EndUserIRISSPWorkFlowSteps;
import serenityTesting.steps.serenity.EndUserSteps;

public class IRISSPWorkFlowSteps {

    @Steps
    EndUserIRISSPWorkFlowSteps endUser;

    @Given("User has Launched IRIS Sharepoint")
    
    public void givenUserHasLaunchedIRISSharepoint() {
      // PENDING
    	endUser.IsUserLaunchedTheSP();
    }

    @Given("User has clicked on Interdiction tab")
    
    public void givenUserHasClickedOnInterdictionTab() {
      // PENDING
    	endUser.UserClickedInterdictionTab();
    }

    @When("User selects an open alert")
    @Given("User has selected an open alert")
    public void whenUserSelectsAnOpenAlert() {
      // PENDING
    	endUser.userSelectsAnOpenAlert();
    }
    
    @Then("System should show the buttons 'Escalate to a New Case' 'Escalate to an Existing Case' 'Close Alert' 'Close' on alert details page")
    public void thenSystemShouldShowTheButtonsEscalateToANewCaseEscalateToAnExistingCaseCloseAlertCloseOnAlertDetailsPage() {
      // PENDING
    	
    	endUser.systemShouldShowTheButtons();
    }
    
    @When("User takes ownership and add comments if necessary and close it as False Positive")
    public void whenUserClosesItAsFalsePositive()
    {
    	
    	endUser.userClosesTheAlertAsFalsePositive();
    }
    
    @Then("Alert should be moved from open alerts to closed alerts")
    public void ThenAlertShouldBeMovedToClosedAlerts()
    {
    	
    	endUser.alertShouldBeMovedToClosedAlerts();
    }
}
