package serenityTesting.steps;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import net.thucydides.core.annotations.Steps;
import serenityTesting.steps.serenity.EndUserFilteringAPISteps;
import serenityTesting.steps.serenity.GithubRestUserAPISteps;

public class FilteringAPISteps {
	
	 @Steps
	 EndUserFilteringAPISteps endUser;
	 String api;
	
	@Given("User has requested with input JSON")
	
	public void givenUserHasRequestedWithInputJSON() {
		
	  // PENDING
		
	}

	@Given("Third Party is SPOT Individual")
	
	public void givenThirdPartyIsSPOTIndividual() {
	  // PENDING
	}

	@Given(" Input JSON includes Suspicious Third Party details for the transaction")
	
	public void givenInputJSONIncludesSuspiciousThirdPartyDetailsForTheTransaction() {
	  // PENDING
	}

	@When("User calls the Filtering API with URL <URL>")
	
	public void whenUserCallsTheFilteringAPIWithURLURL() {
	  // PENDING
	}

	@When("ThirdParty in input JSON Matches with OFAC list key words")
	
	public void whenThirdPartyInInputJSONMatchesWithOFACListKeyWords() {
	  // PENDING
	}

	@Then("Fircosoft should send the response as HIT")
	
	public void thenFircosoftShouldSendTheResponseAsHIT() {
	  // PENDING
	}

	@Then("Filtering API response should have status field as 'Hits'")
	
	public void thenFilteringAPIResponseShouldHaveStatusFieldAsHits() {
	  // PENDING
	}

	@Then("Open the Fircosoft case manager web application and verify that complete scan response should be stored.")
	
	public void thenOpenTheFircosoftCaseManagerWebApplicationAndVerifyThatCompleteScanResponseShouldBeStored() {
	  // PENDING
	}

}
