package serenityTesting.steps.serenity;

import serenityTesting.pages.AlertDetailsPage;
import serenityTesting.pages.CloseAlertPage;
import serenityTesting.pages.DictionaryPage;
import serenityTesting.pages.GoogleHomePage;
import serenityTesting.pages.GoogleSearchResultPage;
import serenityTesting.pages.IRISSPPage;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.hasItem;

public class EndUserGoogleSearchSteps {

	GoogleHomePage googleHomePage;
	GoogleSearchResultPage googleSearchResultPage;

	@Step
	public void isLaunchedGoogleHomePage() {
		// TODO Auto-generated method stub
		
		googleHomePage.open();
	}
	@Step
	public void userEnterWordTobeSearched() {
		// TODO Auto-generated method stub
		googleHomePage.enterWordTobeSearched();
	}
	@Step
	public void userClicksOnSearchButton() {
		// TODO Auto-generated method stub
		googleHomePage.clickOnSearchButton();
	}
	public void systemShouldNavigateToSearchResultPage() {
		// TODO Auto-generated method stub
		googleSearchResultPage.pageShouldbeSearchResultPage();
	}
	
	
	
}