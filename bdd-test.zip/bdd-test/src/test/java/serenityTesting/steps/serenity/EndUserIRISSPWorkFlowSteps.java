package serenityTesting.steps.serenity;

import serenityTesting.pages.AlertDetailsPage;
import serenityTesting.pages.CloseAlertPage;
import serenityTesting.pages.DictionaryPage;
import serenityTesting.pages.IRISSPPage;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.hasItem;

public class EndUserIRISSPWorkFlowSteps {

	IRISSPPage irisSPPage;
	AlertDetailsPage alertDetailsPage;
	CloseAlertPage closeAlertPage;

	@Step
	public void IsUserLaunchedTheSP() {
		// TODO Auto-generated method stub
		
		irisSPPage.open();

	}
	@Step
	public void UserClickedInterdictionTab() {
		// TODO Auto-generated method stub
		irisSPPage.clickOnInterdictionTab();
	}
	
	@Step
	public void userSelectsAnOpenAlert() {
		// TODO Auto-generated method stub
		irisSPPage.selectsInterDictionOpenAlertCategory();
		irisSPPage.saveTheAlertIDAndAlertTitleName();
		irisSPPage.selectsTheMostRecentInterDictionOpenAlert();
	}
	public void systemShouldShowTheButtons() {
		// TODO Auto-generated method stub
		alertDetailsPage.buttonsShouldBeVisible();
	}
	public void userClosesTheAlertAsFalsePositive() {
		// TODO Auto-generated method stub
		
		alertDetailsPage.clickOnCloseAlertButton();
		closeAlertPage.addComments();
		closeAlertPage.clickOnSubmit();
		
		
		
	}
	public void alertShouldBeMovedToClosedAlerts() {
		// TODO Auto-generated method stub
		irisSPPage.selectsInterDictionOpenAlertCategory();
		irisSPPage.IsAlertStillPresentInOpenAlerts();
		
		
		
	}
}