package serenityTesting.pages;

import net.thucydides.core.annotations.DefaultUrl;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import net.serenitybdd.core.pages.WebElementFacade;
import java.util.stream.Collectors;

import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.annotations.findby.FindBy;

import net.thucydides.core.pages.PageObject;

import java.util.List;

//@DefaultUrl("http://en.wiktionary.org/wiki/Wiktionary")
public class CloseAlertPage extends PageObject {


	@FindBy(xpath = ".//*[@id='ctl00_m_g_0309b82f_f813_42db_88d6_ae8979d778e6_CommentsValue']")
	private WebElementFacade txt_add_comments;
	
	@FindBy(xpath = ".//*[@id='ctl00_m_g_0309b82f_f813_42db_88d6_ae8979d778e6']/table/tbody/tr[7]/td/input[1]")
	private WebElementFacade btn_add_submit_buttn;

	/*public void buttonsShouldBeVisible() {
		// TODO Auto-generated method stub
		if (link_take_ownership.isCurrentlyEnabled()) {
			link_take_ownership.click();
		}

		lnk_escalate_to_new_case.shouldBeVisible();
		lnk_escalate_to_an_existing_case.shouldBeVisible();
		lnk_close_alert.shouldBeVisible();

	}
*/
	

	public void addComments() {
		// TODO Auto-generated method stub
		txt_add_comments.type("Closed as false positive by automation");

	}

	public void clickOnSubmit() {
		// TODO Auto-generated method stub
		btn_add_submit_buttn.click();
		
	}
	
}