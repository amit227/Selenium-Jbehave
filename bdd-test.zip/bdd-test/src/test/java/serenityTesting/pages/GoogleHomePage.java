package serenityTesting.pages;

import net.thucydides.core.annotations.DefaultUrl;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import net.serenitybdd.core.pages.WebElementFacade;
import java.util.stream.Collectors;

import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.annotations.findby.FindBy;

import net.thucydides.core.pages.PageObject;

import java.util.List;

//@DefaultUrl("http://en.wiktionary.org/wiki/Wiktionary")
public class GoogleHomePage extends PageObject {

	@FindBy(xpath = ".//*[@id='lst-ib']")
	private WebElementFacade text_search_box;

	@FindBy(xpath = ".//*[@id='tsf']/div[2]/div[3]/center/input[1]")
	private WebElementFacade btn_search;
	

	public void enterWordTobeSearched() {
		// TODO Auto-generated method stub
	
			text_search_box.sendKeys("Western Union");
		

	}

	public void clickOnSearchButton() {
		
		btn_search.click();
	}

}