package serenityTesting.pages;

import net.thucydides.core.annotations.DefaultUrl;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import net.serenitybdd.core.pages.WebElementFacade;
import java.util.stream.Collectors;

import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.annotations.findby.FindBy;

import net.thucydides.core.pages.PageObject;

import java.util.List;

//@DefaultUrl("http://en.wiktionary.org/wiki/Wiktionary")
public class AlertDetailsPage extends PageObject {

	@FindBy(xpath = ".//input[contains(@value,'Take Ownership')]")
	private WebElementFacade link_take_ownership;

	@FindBy(xpath = ".//input[contains(@value,'Escalate to a New Case')]")
	private WebElementFacade lnk_escalate_to_new_case;

	@FindBy(xpath = ".//input[contains(@value,'Escalate to an Existing Case')]")
	private WebElementFacade lnk_escalate_to_an_existing_case;

	@FindBy(xpath = ".//input[contains(@value,'Close Alert')]")
	private WebElementFacade lnk_close_alert;

	public void buttonsShouldBeVisible() {
		// TODO Auto-generated method stub
		if (link_take_ownership.isCurrentlyEnabled()) {
			link_take_ownership.click();
		}

		lnk_escalate_to_new_case.shouldBeVisible();
		lnk_escalate_to_an_existing_case.shouldBeVisible();
		lnk_close_alert.shouldBeVisible();

	}

	public void clickOnCloseAlertButton() {
		// TODO Auto-generated method stub
		if (link_take_ownership.isCurrentlyEnabled()) {
			link_take_ownership.click();
		}
		lnk_close_alert.click();
	}

}