package serenityTesting.pages;

import net.thucydides.core.annotations.DefaultUrl;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import net.serenitybdd.core.pages.WebElementFacade;
import java.util.stream.Collectors;

import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.annotations.findby.FindBy;

import net.thucydides.core.pages.PageObject;

import java.util.Iterator;
import java.util.List;
import static org.assertj.core.api.Assertions.assertThat;

//@DefaultUrl("http://en.wiktionary.org/wiki/Wiktionary")
public class IRISSPPage extends PageObject {

	@FindBy(xpath = ".//*[@id='zz1_TopNavigationMenun2']/table/tbody/tr/td/a")
	private WebElementFacade lnk_Interdiction;

	@FindBy(xpath = ".//*[@id='zz2_QuickLaunchMenun3']/td/table/tbody/tr/td/a")
	private WebElementFacade lnk_open_alerts_interdiction;

	@FindBy(xpath = ".//*[@id='{42ECB176-5F2C-4041-A4D2-126A381D528C}-{FF33D92D-DA78-4A3F-8504-9C0FA3A974C0}']/tbody/tr[3]/td[3]")
	private WebElementFacade lnk_alert_id_of_first_open_alert;

	@FindBy(xpath = ".//*[@id='{42ECB176-5F2C-4041-A4D2-126A381D528C}-{FF33D92D-DA78-4A3F-8504-9C0FA3A974C0}']/tbody/tr[3]/td[2]/table[1]/ tbody/tr[1]/td[1]/a")
	private WebElementFacade lnk_alert_title_of_first_open_alert;

	@FindBy(xpath = ".//*[@id='{42ECB176-5F2C-4041-A4D2-126A381D528C}-{FF33D92D-DA78-4A3F-8504-9C0FA3A974C0}']/tbody/tr[3]/td[2]/table[1]/ tbody/tr[1]/td[1]/a")
	private List<WebElementFacade> lnk_list_of_ids_of_Open_alerts;

	public void clickOnInterdictionTab() {
		lnk_Interdiction.click();
	}

	public List<String> getDefinitions() {
		WebElementFacade definitionList = find(By.tagName("ol"));
		return definitionList.findElements(By.tagName("li")).stream().map(element -> element.getText())
				.collect(Collectors.toList());
	}

	public void selectsInterDictionOpenAlertCategory() {
		// TODO Auto-generated method stub
		lnk_open_alerts_interdiction.click();
	}

	public void selectsTheMostRecentInterDictionOpenAlert() {
		// TODO Auto-generated method stub
		lnk_alert_title_of_first_open_alert.click();
	}

	public void saveTheAlertIDAndAlertTitleName() {
		// TODO Auto-generated method stub
		String alert_id = lnk_alert_id_of_first_open_alert.getText();
		String alert_title_name = lnk_alert_id_of_first_open_alert.getText();
		Serenity.setSessionVariable("alert_id_of_selected_Open_alert").to(alert_id);
		Serenity.setSessionVariable("alert_title_of_selected_Open_alert").to(alert_title_name);
	}

	public void IsAlertStillPresentInOpenAlerts() {
		// TODO Auto-generated method stub

		// Iterator<WebElementFacade> itr =
		// lnk_list_of_ids_of_Open_alerts.iterator();
		// lnk_list_of_ids_of_Open_alerts.stream().forEach(id-);
		String idSelectedAlert = Serenity.sessionVariableCalled("alert_id_of_selected_Open_alert").toString();

	//	assertThat(lnk_list_of_ids_of_Open_alerts.stream().anyMatch(order -> order.getValue().equals(idSelectedAlert)))
	//			.isFalse());
				
	}

}