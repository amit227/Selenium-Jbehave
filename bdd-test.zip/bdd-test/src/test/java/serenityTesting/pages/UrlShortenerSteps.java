package serenityTesting.pages;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONException;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJacksonHttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class UrlShortenerSteps 
 {
	RestTemplate restTemplate;
	HttpHeaders requestHeaders;

	public UrlShortenerSteps() {/*
								 * restTemplate = new RestTemplate();
								 */

		requestHeaders = new HttpHeaders();
		requestHeaders.setContentType(new MediaType("application", "json"));

		// HttpEntity < AuthenticateUser > requestEntity = new HttpEntity <
		// AuthenticateUser > (user, requestHeaders);

		restTemplate = new RestTemplate();
		//restTemplate.getMessageConverters().add(new MappingJacksonHttpMessageConverter());
	//restTemplate.getMessageConverters().add(new StringHttpMessageConverter());

	}
	
	
	

	@Step("longUrl={0}")
	public String shorten(String providedUrl) {
		Map<String, String> urlForm = new HashMap<String, String>();
	//	ObjectMapper mapper = new ObjectMapper();
		urlForm.put("longUrl", providedUrl);
		return restTemplate.postForObject("https://www.googleapis.com/urlshortener/v1/url", urlForm, String.class);
	}

	@Step("shortUrl={0}")
	public String expand(String providedUrl) {
		return restTemplate.getForObject("https://www.googleapis.com/urlshortener/v1/url?shortUrl={shortUrl}",
				String.class, providedUrl);
	}

	@Step
	public void response_should_contain_shortened_url(String returnedMessage, String expectedUrl) throws JSONException {
		String expectedJSONMessage = "{'id':'" + expectedUrl + "'}";
		JSONAssert.assertEquals(expectedJSONMessage, returnedMessage, JSONCompareMode.LENIENT);
	}

	@Step
	public void response_should_contain_long_url(String returnedMessage, String expectedUrl) throws JSONException {
		String expectedJSONMessage = "{'longUrl':'" + expectedUrl + "'}";
		JSONAssert.assertEquals(expectedJSONMessage, returnedMessage, JSONCompareMode.LENIENT);
	}
}