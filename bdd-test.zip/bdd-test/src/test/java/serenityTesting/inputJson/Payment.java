
package serenityTesting.inputJson;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "platform",
    "sourcePaymentID",
    "bookingSystemOrderID",
    "bookingSystemName",
    "orderID",
    "amount",
    "currency",
    "feeAmount",
    "feeCurrency",
    "creationDate",
    "creationDateUTC",
    "orderTypeName",
    "itemTypeName",
    "lineItemID",
    "lastUpdated",
    "lastUpdatedUTC",
    "method",
    "expectedValueDate",
    "deadlineDate",
    "isDoddFrank",
    "notifiedPerson",
    "byOrderOf",
    "yourID",
    "settlementCurrency",
    "buySell",
    "isOutgoing",
    "branchID",
    "delivery",
    "recipient",
    "sender",
    "remitter",
    "authorizedUser",
    "customerID",
    "senderBankAccountID",
    "remitterBankAccountID",
    "intermediaryBankAccountID",
    "parties",
    "bankDetails",
    "wureceiver",
    "bic"
})
public class Payment {

    @JsonProperty("platform")
    private String platform;
    @JsonProperty("sourcePaymentID")
    private String sourcePaymentID;
    @JsonProperty("bookingSystemOrderID")
    private String bookingSystemOrderID;
    @JsonProperty("bookingSystemName")
    private String bookingSystemName;
    @JsonProperty("orderID")
    private String orderID;
    @JsonProperty("amount")
    private String amount;
    @JsonProperty("currency")
    private String currency;
    @JsonProperty("feeAmount")
    private String feeAmount;
    @JsonProperty("feeCurrency")
    private String feeCurrency;
    @JsonProperty("creationDate")
    private String creationDate;
    @JsonProperty("creationDateUTC")
    private String creationDateUTC;
    @JsonProperty("orderTypeName")
    private String orderTypeName;
    @JsonProperty("itemTypeName")
    private String itemTypeName;
    @JsonProperty("lineItemID")
    private String lineItemID;
    @JsonProperty("lastUpdated")
    private String lastUpdated;
    @JsonProperty("lastUpdatedUTC")
    private String lastUpdatedUTC;
    @JsonProperty("method")
    private String method;
    @JsonProperty("expectedValueDate")
    private String expectedValueDate;
    @JsonProperty("deadlineDate")
    private String deadlineDate;
    @JsonProperty("isDoddFrank")
    private String isDoddFrank;
    @JsonProperty("notifiedPerson")
    private NotifiedPerson notifiedPerson;
    @JsonProperty("byOrderOf")
    private String byOrderOf;
    @JsonProperty("yourID")
    private String yourID;
    @JsonProperty("settlementCurrency")
    private String settlementCurrency;
    @JsonProperty("buySell")
    private String buySell;
    @JsonProperty("isOutgoing")
    private String isOutgoing;
    @JsonProperty("branchID")
    private String branchID;
    @JsonProperty("delivery")
    private Delivery delivery;
    @JsonProperty("recipient")
    private Recipient recipient;
    @JsonProperty("sender")
    private Sender sender;
    @JsonProperty("remitter")
    private Remitter remitter;
    @JsonProperty("authorizedUser")
    private AuthorizedUser authorizedUser;
    @JsonProperty("customerID")
    private String customerID;
    @JsonProperty("senderBankAccountID")
    private String senderBankAccountID;
    @JsonProperty("remitterBankAccountID")
    private String remitterBankAccountID;
    @JsonProperty("intermediaryBankAccountID")
    private String intermediaryBankAccountID;
    @JsonProperty("parties")
    private List<Party> parties = new ArrayList<Party>();
    @JsonProperty("bankDetails")
    private List<BankDetail> bankDetails = new ArrayList<BankDetail>();
    @JsonProperty("wureceiver")
    private Wureceiver wureceiver;
    @JsonProperty("bic")
    private String bic;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("platform")
    public String getPlatform() {
        return platform;
    }

    @JsonProperty("platform")
    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public Payment withPlatform(String platform) {
        this.platform = platform;
        return this;
    }

    @JsonProperty("sourcePaymentID")
    public String getSourcePaymentID() {
        return sourcePaymentID;
    }

    @JsonProperty("sourcePaymentID")
    public void setSourcePaymentID(String sourcePaymentID) {
        this.sourcePaymentID = sourcePaymentID;
    }

    public Payment withSourcePaymentID(String sourcePaymentID) {
        this.sourcePaymentID = sourcePaymentID;
        return this;
    }

    @JsonProperty("bookingSystemOrderID")
    public String getBookingSystemOrderID() {
        return bookingSystemOrderID;
    }

    @JsonProperty("bookingSystemOrderID")
    public void setBookingSystemOrderID(String bookingSystemOrderID) {
        this.bookingSystemOrderID = bookingSystemOrderID;
    }

    public Payment withBookingSystemOrderID(String bookingSystemOrderID) {
        this.bookingSystemOrderID = bookingSystemOrderID;
        return this;
    }

    @JsonProperty("bookingSystemName")
    public String getBookingSystemName() {
        return bookingSystemName;
    }

    @JsonProperty("bookingSystemName")
    public void setBookingSystemName(String bookingSystemName) {
        this.bookingSystemName = bookingSystemName;
    }

    public Payment withBookingSystemName(String bookingSystemName) {
        this.bookingSystemName = bookingSystemName;
        return this;
    }

    @JsonProperty("orderID")
    public String getOrderID() {
        return orderID;
    }

    @JsonProperty("orderID")
    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    public Payment withOrderID(String orderID) {
        this.orderID = orderID;
        return this;
    }

    @JsonProperty("amount")
    public String getAmount() {
        return amount;
    }

    @JsonProperty("amount")
    public void setAmount(String amount) {
        this.amount = amount;
    }

    public Payment withAmount(String amount) {
        this.amount = amount;
        return this;
    }

    @JsonProperty("currency")
    public String getCurrency() {
        return currency;
    }

    @JsonProperty("currency")
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public Payment withCurrency(String currency) {
        this.currency = currency;
        return this;
    }

    @JsonProperty("feeAmount")
    public String getFeeAmount() {
        return feeAmount;
    }

    @JsonProperty("feeAmount")
    public void setFeeAmount(String feeAmount) {
        this.feeAmount = feeAmount;
    }

    public Payment withFeeAmount(String feeAmount) {
        this.feeAmount = feeAmount;
        return this;
    }

    @JsonProperty("feeCurrency")
    public String getFeeCurrency() {
        return feeCurrency;
    }

    @JsonProperty("feeCurrency")
    public void setFeeCurrency(String feeCurrency) {
        this.feeCurrency = feeCurrency;
    }

    public Payment withFeeCurrency(String feeCurrency) {
        this.feeCurrency = feeCurrency;
        return this;
    }

    @JsonProperty("creationDate")
    public String getCreationDate() {
        return creationDate;
    }

    @JsonProperty("creationDate")
    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

    public Payment withCreationDate(String creationDate) {
        this.creationDate = creationDate;
        return this;
    }

    @JsonProperty("creationDateUTC")
    public String getCreationDateUTC() {
        return creationDateUTC;
    }

    @JsonProperty("creationDateUTC")
    public void setCreationDateUTC(String creationDateUTC) {
        this.creationDateUTC = creationDateUTC;
    }

    public Payment withCreationDateUTC(String creationDateUTC) {
        this.creationDateUTC = creationDateUTC;
        return this;
    }

    @JsonProperty("orderTypeName")
    public String getOrderTypeName() {
        return orderTypeName;
    }

    @JsonProperty("orderTypeName")
    public void setOrderTypeName(String orderTypeName) {
        this.orderTypeName = orderTypeName;
    }

    public Payment withOrderTypeName(String orderTypeName) {
        this.orderTypeName = orderTypeName;
        return this;
    }

    @JsonProperty("itemTypeName")
    public String getItemTypeName() {
        return itemTypeName;
    }

    @JsonProperty("itemTypeName")
    public void setItemTypeName(String itemTypeName) {
        this.itemTypeName = itemTypeName;
    }

    public Payment withItemTypeName(String itemTypeName) {
        this.itemTypeName = itemTypeName;
        return this;
    }

    @JsonProperty("lineItemID")
    public String getLineItemID() {
        return lineItemID;
    }

    @JsonProperty("lineItemID")
    public void setLineItemID(String lineItemID) {
        this.lineItemID = lineItemID;
    }

    public Payment withLineItemID(String lineItemID) {
        this.lineItemID = lineItemID;
        return this;
    }

    @JsonProperty("lastUpdated")
    public String getLastUpdated() {
        return lastUpdated;
    }

    @JsonProperty("lastUpdated")
    public void setLastUpdated(String lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public Payment withLastUpdated(String lastUpdated) {
        this.lastUpdated = lastUpdated;
        return this;
    }

    @JsonProperty("lastUpdatedUTC")
    public String getLastUpdatedUTC() {
        return lastUpdatedUTC;
    }

    @JsonProperty("lastUpdatedUTC")
    public void setLastUpdatedUTC(String lastUpdatedUTC) {
        this.lastUpdatedUTC = lastUpdatedUTC;
    }

    public Payment withLastUpdatedUTC(String lastUpdatedUTC) {
        this.lastUpdatedUTC = lastUpdatedUTC;
        return this;
    }

    @JsonProperty("method")
    public String getMethod() {
        return method;
    }

    @JsonProperty("method")
    public void setMethod(String method) {
        this.method = method;
    }

    public Payment withMethod(String method) {
        this.method = method;
        return this;
    }

    @JsonProperty("expectedValueDate")
    public String getExpectedValueDate() {
        return expectedValueDate;
    }

    @JsonProperty("expectedValueDate")
    public void setExpectedValueDate(String expectedValueDate) {
        this.expectedValueDate = expectedValueDate;
    }

    public Payment withExpectedValueDate(String expectedValueDate) {
        this.expectedValueDate = expectedValueDate;
        return this;
    }

    @JsonProperty("deadlineDate")
    public String getDeadlineDate() {
        return deadlineDate;
    }

    @JsonProperty("deadlineDate")
    public void setDeadlineDate(String deadlineDate) {
        this.deadlineDate = deadlineDate;
    }

    public Payment withDeadlineDate(String deadlineDate) {
        this.deadlineDate = deadlineDate;
        return this;
    }

    @JsonProperty("isDoddFrank")
    public String getIsDoddFrank() {
        return isDoddFrank;
    }

    @JsonProperty("isDoddFrank")
    public void setIsDoddFrank(String isDoddFrank) {
        this.isDoddFrank = isDoddFrank;
    }

    public Payment withIsDoddFrank(String isDoddFrank) {
        this.isDoddFrank = isDoddFrank;
        return this;
    }

    @JsonProperty("notifiedPerson")
    public NotifiedPerson getNotifiedPerson() {
        return notifiedPerson;
    }

    @JsonProperty("notifiedPerson")
    public void setNotifiedPerson(NotifiedPerson notifiedPerson) {
        this.notifiedPerson = notifiedPerson;
    }

    public Payment withNotifiedPerson(NotifiedPerson notifiedPerson) {
        this.notifiedPerson = notifiedPerson;
        return this;
    }

    @JsonProperty("byOrderOf")
    public String getByOrderOf() {
        return byOrderOf;
    }

    @JsonProperty("byOrderOf")
    public void setByOrderOf(String byOrderOf) {
        this.byOrderOf = byOrderOf;
    }

    public Payment withByOrderOf(String byOrderOf) {
        this.byOrderOf = byOrderOf;
        return this;
    }

    @JsonProperty("yourID")
    public String getYourID() {
        return yourID;
    }

    @JsonProperty("yourID")
    public void setYourID(String yourID) {
        this.yourID = yourID;
    }

    public Payment withYourID(String yourID) {
        this.yourID = yourID;
        return this;
    }

    @JsonProperty("settlementCurrency")
    public String getSettlementCurrency() {
        return settlementCurrency;
    }

    @JsonProperty("settlementCurrency")
    public void setSettlementCurrency(String settlementCurrency) {
        this.settlementCurrency = settlementCurrency;
    }

    public Payment withSettlementCurrency(String settlementCurrency) {
        this.settlementCurrency = settlementCurrency;
        return this;
    }

    @JsonProperty("buySell")
    public String getBuySell() {
        return buySell;
    }

    @JsonProperty("buySell")
    public void setBuySell(String buySell) {
        this.buySell = buySell;
    }

    public Payment withBuySell(String buySell) {
        this.buySell = buySell;
        return this;
    }

    @JsonProperty("isOutgoing")
    public String getIsOutgoing() {
        return isOutgoing;
    }

    @JsonProperty("isOutgoing")
    public void setIsOutgoing(String isOutgoing) {
        this.isOutgoing = isOutgoing;
    }

    public Payment withIsOutgoing(String isOutgoing) {
        this.isOutgoing = isOutgoing;
        return this;
    }

    @JsonProperty("branchID")
    public String getBranchID() {
        return branchID;
    }

    @JsonProperty("branchID")
    public void setBranchID(String branchID) {
        this.branchID = branchID;
    }

    public Payment withBranchID(String branchID) {
        this.branchID = branchID;
        return this;
    }

    @JsonProperty("delivery")
    public Delivery getDelivery() {
        return delivery;
    }

    @JsonProperty("delivery")
    public void setDelivery(Delivery delivery) {
        this.delivery = delivery;
    }

    public Payment withDelivery(Delivery delivery) {
        this.delivery = delivery;
        return this;
    }

    @JsonProperty("recipient")
    public Recipient getRecipient() {
        return recipient;
    }

    @JsonProperty("recipient")
    public void setRecipient(Recipient recipient) {
        this.recipient = recipient;
    }

    public Payment withRecipient(Recipient recipient) {
        this.recipient = recipient;
        return this;
    }

    @JsonProperty("sender")
    public Sender getSender() {
        return sender;
    }

    @JsonProperty("sender")
    public void setSender(Sender sender) {
        this.sender = sender;
    }

    public Payment withSender(Sender sender) {
        this.sender = sender;
        return this;
    }

    @JsonProperty("remitter")
    public Remitter getRemitter() {
        return remitter;
    }

    @JsonProperty("remitter")
    public void setRemitter(Remitter remitter) {
        this.remitter = remitter;
    }

    public Payment withRemitter(Remitter remitter) {
        this.remitter = remitter;
        return this;
    }

    @JsonProperty("authorizedUser")
    public AuthorizedUser getAuthorizedUser() {
        return authorizedUser;
    }

    @JsonProperty("authorizedUser")
    public void setAuthorizedUser(AuthorizedUser authorizedUser) {
        this.authorizedUser = authorizedUser;
    }

    public Payment withAuthorizedUser(AuthorizedUser authorizedUser) {
        this.authorizedUser = authorizedUser;
        return this;
    }

    @JsonProperty("customerID")
    public String getCustomerID() {
        return customerID;
    }

    @JsonProperty("customerID")
    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public Payment withCustomerID(String customerID) {
        this.customerID = customerID;
        return this;
    }

    @JsonProperty("senderBankAccountID")
    public String getSenderBankAccountID() {
        return senderBankAccountID;
    }

    @JsonProperty("senderBankAccountID")
    public void setSenderBankAccountID(String senderBankAccountID) {
        this.senderBankAccountID = senderBankAccountID;
    }

    public Payment withSenderBankAccountID(String senderBankAccountID) {
        this.senderBankAccountID = senderBankAccountID;
        return this;
    }

    @JsonProperty("remitterBankAccountID")
    public String getRemitterBankAccountID() {
        return remitterBankAccountID;
    }

    @JsonProperty("remitterBankAccountID")
    public void setRemitterBankAccountID(String remitterBankAccountID) {
        this.remitterBankAccountID = remitterBankAccountID;
    }

    public Payment withRemitterBankAccountID(String remitterBankAccountID) {
        this.remitterBankAccountID = remitterBankAccountID;
        return this;
    }

    @JsonProperty("intermediaryBankAccountID")
    public String getIntermediaryBankAccountID() {
        return intermediaryBankAccountID;
    }

    @JsonProperty("intermediaryBankAccountID")
    public void setIntermediaryBankAccountID(String intermediaryBankAccountID) {
        this.intermediaryBankAccountID = intermediaryBankAccountID;
    }

    public Payment withIntermediaryBankAccountID(String intermediaryBankAccountID) {
        this.intermediaryBankAccountID = intermediaryBankAccountID;
        return this;
    }

    @JsonProperty("parties")
    public List<Party> getParties() {
        return parties;
    }

    @JsonProperty("parties")
    public void setParties(List<Party> parties) {
        this.parties = parties;
    }

    public Payment withParties(List<Party> parties) {
        this.parties = parties;
        return this;
    }

    @JsonProperty("bankDetails")
    public List<BankDetail> getBankDetails() {
        return bankDetails;
    }

    @JsonProperty("bankDetails")
    public void setBankDetails(List<BankDetail> bankDetails) {
        this.bankDetails = bankDetails;
    }

    public Payment withBankDetails(List<BankDetail> bankDetails) {
        this.bankDetails = bankDetails;
        return this;
    }

    @JsonProperty("wureceiver")
    public Wureceiver getWureceiver() {
        return wureceiver;
    }

    @JsonProperty("wureceiver")
    public void setWureceiver(Wureceiver wureceiver) {
        this.wureceiver = wureceiver;
    }

    public Payment withWureceiver(Wureceiver wureceiver) {
        this.wureceiver = wureceiver;
        return this;
    }

    @JsonProperty("bic")
    public String getBic() {
        return bic;
    }

    @JsonProperty("bic")
    public void setBic(String bic) {
        this.bic = bic;
    }

    public Payment withBic(String bic) {
        this.bic = bic;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Payment withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(platform).append(sourcePaymentID).append(bookingSystemOrderID).append(bookingSystemName).append(orderID).append(amount).append(currency).append(feeAmount).append(feeCurrency).append(creationDate).append(creationDateUTC).append(orderTypeName).append(itemTypeName).append(lineItemID).append(lastUpdated).append(lastUpdatedUTC).append(method).append(expectedValueDate).append(deadlineDate).append(isDoddFrank).append(notifiedPerson).append(byOrderOf).append(yourID).append(settlementCurrency).append(buySell).append(isOutgoing).append(branchID).append(delivery).append(recipient).append(sender).append(remitter).append(authorizedUser).append(customerID).append(senderBankAccountID).append(remitterBankAccountID).append(intermediaryBankAccountID).append(parties).append(bankDetails).append(wureceiver).append(bic).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Payment) == false) {
            return false;
        }
        Payment rhs = ((Payment) other);
        return new EqualsBuilder().append(platform, rhs.platform).append(sourcePaymentID, rhs.sourcePaymentID).append(bookingSystemOrderID, rhs.bookingSystemOrderID).append(bookingSystemName, rhs.bookingSystemName).append(orderID, rhs.orderID).append(amount, rhs.amount).append(currency, rhs.currency).append(feeAmount, rhs.feeAmount).append(feeCurrency, rhs.feeCurrency).append(creationDate, rhs.creationDate).append(creationDateUTC, rhs.creationDateUTC).append(orderTypeName, rhs.orderTypeName).append(itemTypeName, rhs.itemTypeName).append(lineItemID, rhs.lineItemID).append(lastUpdated, rhs.lastUpdated).append(lastUpdatedUTC, rhs.lastUpdatedUTC).append(method, rhs.method).append(expectedValueDate, rhs.expectedValueDate).append(deadlineDate, rhs.deadlineDate).append(isDoddFrank, rhs.isDoddFrank).append(notifiedPerson, rhs.notifiedPerson).append(byOrderOf, rhs.byOrderOf).append(yourID, rhs.yourID).append(settlementCurrency, rhs.settlementCurrency).append(buySell, rhs.buySell).append(isOutgoing, rhs.isOutgoing).append(branchID, rhs.branchID).append(delivery, rhs.delivery).append(recipient, rhs.recipient).append(sender, rhs.sender).append(remitter, rhs.remitter).append(authorizedUser, rhs.authorizedUser).append(customerID, rhs.customerID).append(senderBankAccountID, rhs.senderBankAccountID).append(remitterBankAccountID, rhs.remitterBankAccountID).append(intermediaryBankAccountID, rhs.intermediaryBankAccountID).append(parties, rhs.parties).append(bankDetails, rhs.bankDetails).append(wureceiver, rhs.wureceiver).append(bic, rhs.bic).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
