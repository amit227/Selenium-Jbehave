
package serenityTesting.inputJson;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "industryType",
    "legalName",
    "customerCategory",
    "lei"
})
public class Company {

    @JsonProperty("industryType")
    private String industryType;
    @JsonProperty("legalName")
    private String legalName;
    @JsonProperty("customerCategory")
    private String customerCategory;
    @JsonProperty("lei")
    private String lei;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("industryType")
    public String getIndustryType() {
        return industryType;
    }

    @JsonProperty("industryType")
    public void setIndustryType(String industryType) {
        this.industryType = industryType;
    }

    public Company withIndustryType(String industryType) {
        this.industryType = industryType;
        return this;
    }

    @JsonProperty("legalName")
    public String getLegalName() {
        return legalName;
    }

    @JsonProperty("legalName")
    public void setLegalName(String legalName) {
        this.legalName = legalName;
    }

    public Company withLegalName(String legalName) {
        this.legalName = legalName;
        return this;
    }

    @JsonProperty("customerCategory")
    public String getCustomerCategory() {
        return customerCategory;
    }

    @JsonProperty("customerCategory")
    public void setCustomerCategory(String customerCategory) {
        this.customerCategory = customerCategory;
    }

    public Company withCustomerCategory(String customerCategory) {
        this.customerCategory = customerCategory;
        return this;
    }

    @JsonProperty("lei")
    public String getLei() {
        return lei;
    }

    @JsonProperty("lei")
    public void setLei(String lei) {
        this.lei = lei;
    }

    public Company withLei(String lei) {
        this.lei = lei;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Company withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(industryType).append(legalName).append(customerCategory).append(lei).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Company) == false) {
            return false;
        }
        Company rhs = ((Company) other);
        return new EqualsBuilder().append(industryType, rhs.industryType).append(legalName, rhs.legalName).append(customerCategory, rhs.customerCategory).append(lei, rhs.lei).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
